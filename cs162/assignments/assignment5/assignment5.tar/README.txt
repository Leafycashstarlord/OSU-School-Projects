Name: Jackson E. Rollins
Date: 6/7/2020
Program: Linked List Implementation
Assignment #5

I wrote the program following all of the guidlines, minus the extra credit. I have done no extra credit.
When individually testing each of my functions, I was able to get most of them working, but when I put them all together
into the one driver file I started running into the some problems. When adding the first node to the list, I repeatedly got the error
"Conditional jump or move depends of uninitialised values" with a lot of memory being leaked. I was able to fix the memory leaks
happening, but I then started to get another error, "Use of uninitialised value size of 8," and with it came a seg-fault. I pinpointed
the location of the seg-fault/error at the creation o fthe first node in the list, but I wasn't sure what was breaking exactly, or what
the error meant, even after looking it up for context. In the end, I ran out of time and am submitting what I have.

Thanks for the great term, all things considered. Have a great summer.
