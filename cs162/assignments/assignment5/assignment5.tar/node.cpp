/****************
 *Jackson E. Rollins
 *6/7/2020
 *Implementation file for the node class
 * *************/
#include <iostream>
#include <string>
#include "node.h"

using namespace std;

//Default constructor for the node class
Node::Node(){
	val = 0;
	next = NULL;
}
