/*************
 * Header  file for the gent_int function
 * Author: Jackson E. Rollins
 * ***********/

#include <iostream>
#include <string>

using namespace std;

int get_int(string);
