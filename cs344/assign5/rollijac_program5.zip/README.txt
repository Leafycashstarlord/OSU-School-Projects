You can compile if you run the Makefile by using the command "make".
