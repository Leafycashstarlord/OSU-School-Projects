You can compile in 1 of 2 ways.

1. run the Makefile by running the command "make"

or if the Makefile doesn't work

2. run the command "gcc -std=gnu99 -g -Wall -o movies_by_year moviesByYear.c"
